# Self-Hosted Automated Email Marketing System
## For LK Digital Solutions - Gauteng IT Services

---

## SYSTEM OVERVIEW

You'll run a local marketing automation system that:
- Scrapes/collects business emails from public sources
- Sends personalized cold emails automatically
- Tracks opens, clicks, and replies
- Follows up automatically with non-responders
- Manages your email reputation to avoid spam folders

**Total Cost: R0/month** (assuming you have a computer that can run 24/7)

---

## STACK COMPONENTS

### 1. Email Sending Infrastructure
**Option A: Use Your Existing Domain Email (Recommended to start)**
- Your existing email: info@lutendotech.com or sales@lutendotech.com
- SMTP credentials from your hosting provider
- Free tier limit: depends on your host (usually 500-1000/day)

**Option B: SendGrid Free Tier**
- 100 emails/day forever free
- Better deliverability than shared hosting
- Signup: https://sendgrid.com

**Option C: Mailgun Free Tier**
- 5,000 emails/month free (first 3 months)
- Then $0.80 per 1,000 emails
- Better for volume: https://mailgun.com

### 2. Automation Software (Running on Your Machine)

**MAUTIC (Open Source Marketing Automation)**
- Self-hosted on your local machine
- Features: Email campaigns, segmentation, A/B testing, tracking
- Install via Docker (easiest method)

**Alternative: n8n (Workflow Automation)**
- More flexible, can integrate with everything
- Visual workflow builder
- Also free and self-hosted

---

## STEP-BY-STEP SETUP

### PHASE 1: INFRASTRUCTURE (Day 1)

#### Step 1: Install Docker Desktop
```bash
# For Ubuntu/Linux
sudo apt update
sudo apt install docker.io docker-compose
sudo systemctl start docker
sudo systemctl enable docker

# For Windows: Download Docker Desktop
# https://www.docker.com/products/docker-desktop
```

#### Step 2: Set Up Mautic (Marketing Automation Platform)
```bash
# Create directory
mkdir ~/mautic-marketing
cd ~/mautic-marketing

# Create docker-compose.yml file
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  mautic:
    image: mautic/mautic:latest
    container_name: mautic
    restart: unless-stopped
    ports:
      - "8080:80"
    environment:
      - MAUTIC_DB_HOST=db
      - MAUTIC_DB_USER=mautic
      - MAUTIC_DB_PASSWORD=mauticdbpass
      - MAUTIC_DB_NAME=mautic
    volumes:
      - mautic_data:/var/www/html
    depends_on:
      - db

  db:
    image: mysql:5.7
    container_name: mautic_db
    restart: unless-stopped
    environment:
      - MYSQL_ROOT_PASSWORD=rootpass
      - MYSQL_DATABASE=mautic
      - MYSQL_USER=mautic
      - MYSQL_PASSWORD=mauticdbpass
    volumes:
      - db_data:/var/lib/mysql

volumes:
  mautic_data:
  db_data:
EOF

# Start Mautic
docker-compose up -d

# Access at: http://localhost:8080
```

#### Step 3: Configure Your Sending Email
In Mautic (http://localhost:8080):
1. Complete setup wizard
2. Go to Settings > Email Settings
3. Add your SMTP details:
   - **Service:** Other SMTP
   - **Host:** smtp.yourhost.com (get from your hosting provider)
   - **Port:** 587 (TLS) or 465 (SSL)
   - **Username:** sales@lutendotech.com
   - **Password:** [your email password]
   - **Encryption:** TLS

---

### PHASE 2: BUILD YOUR TARGET LIST (Day 2-3)

#### Method 1: Manual Collection (Most Reliable)
**Sources for Gauteng Business Emails:**
1. **Google My Business Listings**
   - Search "accounting firms Gauteng"
   - Search "law firms Pretoria"
   - Search "manufacturing companies Johannesburg"
   - Collect: business name, website, phone

2. **LinkedIn Sales Navigator Free Trial**
   - Filter: Location (Gauteng), Industry, Company Size
   - Export contact info
   - 30-day free trial

3. **Public Business Directories**
   - https://www.hotfrog.co.za
   - https://www.brabys.com
   - Local chamber of commerce listings

4. **Industry Associations**
   - SAIT (accountants)
   - Law Society directories
   - Industry-specific associations

#### Method 2: Semi-Automated Scraping

**Tool: Apollo.io (Free Tier)**
- 10,000 email credits/year free
- Export to CSV
- Filters: Location (South Africa), Company size, Industry

**Create a spreadsheet with:**
```
First Name | Last Name | Email | Company | Industry | Website
John | Smith | john@company.co.za | ABC Corp | Manufacturing | abc.co.za
```

#### Method 3: Web Scraping (Advanced)
```python
# Simple Python script to extract emails from websites
# Save as email_scraper.py

import re
import requests
from bs4 import BeautifulSoup

def scrape_emails_from_website(url):
    try:
        response = requests.get(url, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find all emails using regex
        emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', response.text)
        
        # Remove duplicates
        emails = list(set(emails))
        
        # Filter out common false positives
        filtered = [e for e in emails if not any(x in e.lower() for x in ['example', 'test', 'spam', 'noreply'])]
        
        return filtered
    except:
        return []

# Usage
websites = [
    'https://company1.co.za/contact',
    'https://company2.co.za/about',
]

for site in websites:
    print(f"\n{site}")
    emails = scrape_emails_from_website(site)
    print(emails)
```

**IMPORTANT:** Only use publicly available information. Don't scrape personal data or violate POPIA (SA privacy law).

---

### PHASE 3: EMAIL CAMPAIGNS (Day 4-5)

#### Campaign Structure (3-Email Sequence)

**EMAIL 1: The Problem (Day 0)**
```
Subject: Quick question about [Company Name]'s IT setup

Hi [First Name],

I noticed [Company Name] while researching Gauteng businesses in [Industry].

Most [Industry] companies I work with struggle with:
- Unexpected downtime costing thousands per hour
- No clear IT budget (surprise bills every month)
- Staff waiting hours for basic tech support

Does any of this sound familiar?

We help Gauteng businesses lock in predictable IT costs and cut downtime by 90%.

Worth a 15-minute chat?

Lutendo
LK Digital Solutions
[Phone]
```

**EMAIL 2: Social Proof (Day 3 - if no reply)**
```
Subject: Following up - [Company Name]

Hi [First Name],

Not sure if you saw my message earlier this week.

Quick update: We just helped a [similar industry] company in Centurion reduce their IT costs by R18,000/month while improving response times from 4 hours to 20 minutes.

Their main issue was [specific problem relevant to industry].

If that sounds relevant to [Company Name], let me know. Happy to share what we did.

Lutendo
```

**EMAIL 3: Break-Up Email (Day 7 - if no reply)**
```
Subject: Should I close your file?

Hi [First Name],

I haven't heard back, so I'm guessing:

A) You're already happy with your IT setup (great!)
B) Timing isn't right
C) My emails are going to spam (oops)

I'll close your file unless I hear otherwise.

If IT costs or downtime become an issue down the line, you know where to find me.

All the best,
Lutendo
```

#### Setting Up the Campaign in Mautic

1. **Create Segments**
   - Go to Contacts > Segments
   - Create: "Gauteng Manufacturing", "Gauteng Legal", "Gauteng Accounting", etc.
   - Upload your CSV lists to each segment

2. **Create Email Templates**
   - Go to Channels > Emails
   - Create 3 emails (Email 1, 2, 3 from above)
   - Use {contactfield=firstname} for personalization
   - Use {contactfield=company} for company name

3. **Build Campaign Workflow**
   - Go to Campaigns > New
   - Name: "Cold Outreach - [Industry]"
   
   **Campaign Flow:**
   ```
   [Contact Added to Segment]
         ↓
   [Wait 1 hour] → [Send Email 1]
         ↓
   [Decision: Email Opened?]
      ↙         ↘
   YES          NO
   [Wait 3 days] [Wait 3 days]
   [Send Email 2] [Send Email 2]
         ↓
   [Decision: Email Opened OR Replied?]
      ↙         ↘
   YES          NO
   [Stop]    [Wait 4 days]
             [Send Email 3]
                ↓
             [Stop]
   ```

4. **Set Sending Limits (Critical to Avoid Spam Flags)**
   - Settings > Configuration > Email Settings
   - **Frequency Rules:** Max 1 email per contact per day
   - **Sending Limits:** 
     - Start with 50 emails/day for first week
     - Increase to 100/day in week 2
     - Max 200/day by week 3
   - **Time throttling:** Send between 9am-5pm SAST only

---

### PHASE 4: REPUTATION MANAGEMENT (Ongoing)

#### Email Warmup (First 2 Weeks)
**Week 1:**
- Send 20-30 emails/day
- Send to people you know first (colleagues, friends in business)
- Get them to reply and mark as "Not Spam"

**Week 2:**
- Increase to 50 emails/day
- Mix of warm contacts and cold prospects

#### Technical Setup to Improve Deliverability

**1. SPF Record (Add to DNS)**
```
v=spf1 include:_spf.google.com include:sendgrid.net ~all
```

**2. DKIM Setup**
- Get DKIM keys from your email provider
- Add to DNS as TXT record

**3. DMARC Record**
```
v=DMARC1; p=none; rua=mailto:admin@lutendotech.com
```

**4. Unsubscribe Link (Required by Law)**
Add to every email footer:
```
---
Unsubscribe: {unsubscribe_url}
LK Digital Solutions | Gauteng, South Africa
```

#### Monitoring Email Health

**Free Tools:**
1. **Mail-Tester.com** - Score your email /10
2. **MXToolbox.com** - Check if you're blacklisted
3. **GlockApps.com** - Free trial for inbox placement testing

**Red Flags to Watch:**
- Bounce rate >5% = clean your list
- Spam complaint rate >0.1% = stop and review content
- Open rate <15% = subject lines need work

---

### PHASE 5: AUTOMATION WORKFLOWS (Advanced)

#### Auto-Responder for Website Inquiries
```
When: Someone fills contact form on website
Then:
1. Add to "Website Leads" segment
2. Send instant reply: "Thanks, we'll respond in 24 hours"
3. Wait 24 hours
4. If not contacted: Assign to sales queue
5. Send internal alert: "Lead needs follow-up"
```

#### Lead Scoring
```
Points System:
+5  Opened email
+10 Clicked link in email
+20 Visited pricing page
+50 Downloaded resource
+100 Replied to email

When score >50: Move to "Hot Leads" segment
When score >100: Send alert + priority follow-up
```

#### Automated LinkedIn Outreach (Using n8n)
```
1. Export contacts from Mautic
2. Use n8n to:
   - Search person on LinkedIn
   - Send connection request with note
   - If accepted, send thank you message
   - Add note to Mautic contact
```

---

### PHASE 6: CONTENT AUTOMATION

#### Weekly LinkedIn Posts (Automated)
Use **Buffer** (free tier: 10 scheduled posts)
- Schedule 3 posts/week
- Content themes:
  - Monday: IT tip of the week
  - Wednesday: Case study/client win
  - Friday: Industry news + your take

#### Email Newsletter (Monthly)
- Segment: "Existing Clients" + "Engaged Prospects"
- Content: IT security tips, Gauteng business news, company updates
- Goal: Stay top-of-mind without selling

---

## TARGETING STRATEGY

### Ideal Customer Profile for Gauteng
**Industry Priority:**
1. **Accounting Firms** (5-50 employees)
   - Pain: Client data security, compliance
   - Budget: R8,000-R25,000/month
   
2. **Legal Firms** (3-30 employees)
   - Pain: Document management, email reliability
   - Budget: R6,000-R20,000/month

3. **Small Manufacturing** (10-100 employees)
   - Pain: Production downtime, old systems
   - Budget: R10,000-R40,000/month

4. **Medical Practices** (2-20 employees)
   - Pain: Patient data security, appointment systems
   - Budget: R5,000-R15,000/month

### List Building Goals
- **Month 1:** 500 quality contacts
- **Month 2:** 1,000 contacts
- **Month 3:** 2,000+ contacts

### Expected Results (Industry Average)
- **Open Rate:** 20-30%
- **Reply Rate:** 1-3%
- **Meeting Conversion:** 0.5-1%

**Translation:**
- Send to 1,000 contacts → 250 opens → 20 replies → 5-10 meetings → 1-2 clients

---

## DAILY OPERATIONS CHECKLIST

### Morning Routine (15 minutes)
- [ ] Check Mautic dashboard for replies
- [ ] Respond to any inquiries within 2 hours
- [ ] Review yesterday's email performance
- [ ] Add new contacts to segments (if collected)

### Weekly Tasks (1 hour)
- [ ] Monday: Upload new contacts from research
- [ ] Wednesday: Review campaign performance, adjust
- [ ] Friday: Plan next week's content/segments

### Monthly Review (2 hours)
- [ ] Calculate conversion rates
- [ ] Clean email list (remove bounces)
- [ ] Test new email copy (A/B test)
- [ ] Expand to new industry segment

---

## LEGAL COMPLIANCE (POPIA - SA Law)

### Requirements:
1. **Consent:** For cold emails, legitimate interest applies (B2B is okay)
2. **Unsubscribe:** Must have working unsubscribe link
3. **Identification:** Must clearly identify your business
4. **Honesty:** No misleading subject lines

### Email Footer Template:
```
---
LK Digital Solutions (Pty) Ltd
Managed IT Services | Gauteng, South Africa
Email: info@lutendotech.com | Phone: [Your Number]

You're receiving this because we believe our services may benefit your business.
Unsubscribe: {unsubscribe_url}
```

---

## BACKUP & MAINTENANCE

### Keep Your System Running 24/7

**Option 1: Old Laptop/Desktop**
- Install Ubuntu Server
- Run Docker containers
- Cost: R0 (electricity ~R200/month)

**Option 2: Raspberry Pi 4**
- Cost: ~R1,500 one-time
- Power usage: ~R20/month
- Perfect for this use case

**Option 3: Free Cloud Hosting**
- Oracle Cloud (Always Free Tier)
- Google Cloud (Free trial R6,000 credit)
- AWS (12 months free)

### Backup Strategy
```bash
# Weekly backup script
#!/bin/bash
docker exec mautic_db mysqldump -u mautic -pmauticdbpass mautic > backup_$(date +%Y%m%d).sql
# Upload to Google Drive or Dropbox
```

---

## SCALING UP (When You Get Clients)

### Month 3-6: When Budget Allows
1. **Upgrade to Paid Email Service**
   - SendGrid: R750/month (40,000 emails)
   - Better deliverability, more volume

2. **Hire VA for List Building**
   - Philippines VA: R3,000-R5,000/month
   - Task: Research and collect 500 contacts/week

3. **Add Phone Outreach**
   - Call warm leads (opened 3+ emails)
   - Script provided separately

---

## TROUBLESHOOTING

### "My emails are going to spam"
- Check SPF/DKIM/DMARC records
- Reduce sending volume
- Improve email copy (less salesy)
- Get people to whitelist you

### "No one is opening my emails"
- Test subject lines (A/B test)
- Verify emails are valid (use NeverBounce free tier)
- Send test to yourself first

### "I'm getting unsubscribes"
- Normal: 1-2% is okay
- If >5%: Your targeting is off
- Review ICP and refine list

### "Mautic is slow/crashing"
- Increase Docker memory allocation
- Optimize database (run cleanup)
- Move to cloud instance

---

## QUICK START SUMMARY

**Week 1:**
- Day 1: Install Docker + Mautic
- Day 2-3: Collect 100 target contacts
- Day 4: Set up first email sequence
- Day 5: Send first 20 test emails
- Day 6-7: Monitor and adjust

**Week 2-4:**
- Increase volume slowly (20→50→100/day)
- Add more segments (new industries)
- Refine email copy based on responses
- Goal: 500 emails sent, 5-10 replies, 1-2 meetings

---

## RESOURCES & TOOLS

### Free Tools You'll Use:
- **Mautic** - Marketing automation
- **Docker** - Container platform
- **Apollo.io** - Lead database (10k free credits)
- **Hunter.io** - Email finder (50 free searches/month)
- **Mail-Tester** - Email deliverability checker
- **Canva** - Email graphics (free tier)
- **Buffer** - Social media scheduling (10 posts/month free)

### Learning Resources:
- Mautic Documentation: https://docs.mautic.org
- Cold Email Masterclass: https://www.coldiq.com/academy
- POPIA Compliance: https://popia.co.za

---

## NEXT STEPS

1. Install Docker and Mautic (today)
2. Configure your sending email (today)
3. Collect your first 50 contacts (this week)
4. Set up your first 3-email campaign (this week)
5. Send your first batch (end of week)

**Questions or stuck on any step? Let me know and I'll help you troubleshoot.**

---

*Last Updated: May 2026*
*For: LK Digital Solutions - Gauteng IT Services*
