# Email Templates for LK Digital Solutions
## Cold Outreach Sequences by Industry

---

## TEMPLATE SET 1: ACCOUNTING FIRMS

### Email 1 - The Problem
**Subject:** Quick question about [Company Name]'s IT

Hi [First Name],

I work with accounting firms across Gauteng and noticed a pattern.

Most are dealing with:
• Client data sitting on laptops (not backed up properly)
• Tax season slowdowns when systems crash
• Staff sharing passwords for practice management software

Sound familiar?

We help firms like yours lock in predictable IT costs and keep client data secure.

Worth a quick chat?

Lutendo Kekana
LK Digital Solutions
sales@lutendotech.com
[Your Phone]

---
This is a business communication. Unsubscribe: {unsubscribe_url}

---

### Email 2 - Case Study
**Subject:** Re: [Company Name]'s IT

Hi [First Name],

Following up from earlier this week.

We recently worked with a 12-person accounting firm in Pretoria. Their main issues:
• Server crashed during tax season (lost 2 days of work)
• R15,000/month in random IT fixes
• No backup when ransomware hit a client file

We moved them to a fixed R8,500/month plan with:
• Cloud backup (tested monthly)
• 30-minute response time
• No surprise bills

They haven't had downtime in 8 months.

If you're curious about the setup, I can send details.

Lutendo

---

### Email 3 - Breakup
**Subject:** Closing your file

Hi [First Name],

Haven't heard back, so I'm assuming IT isn't a priority right now.

I'll close your file.

If systems crash or costs spike, you know where to find me.

Good luck with [upcoming tax season/busy period],
Lutendo

---

## TEMPLATE SET 2: LAW FIRMS

### Email 1 - The Problem
**Subject:** IT question for [Company Name]

Hi [First Name],

I help law firms in Gauteng with something specific: making sure your email never goes down during a critical case.

Most firms I talk to worry about:
• Losing emails with case documents attached
• Staff locked out during client emergencies
• Practice management software crashing before deadlines

Does [Company Name] have a backup plan when systems fail?

We provide same-day support with guaranteed response times.

10 minutes to discuss?

Lutendo Kekana
LK Digital Solutions

---

### Email 2 - Social Proof
**Subject:** Following up - [Company Name]

Hi [First Name],

Not sure if my earlier email got buried.

Quick story: A 6-attorney firm in Sandton called us in a panic. Their server died the day before a court filing deadline.

We had them back online in 4 hours (instead of the 2-3 days their old IT company quoted).

They're now on our managed plan. No more emergencies.

If reliable IT matters to [Company Name], let's talk.

Lutendo

---

### Email 3 - Final
**Subject:** Should I follow up?

Hi [First Name],

This is my last email unless I hear back.

If IT is already sorted, great. If not, and something breaks at the worst time, you'll know who to call.

All the best,
Lutendo

---

## TEMPLATE SET 3: SMALL MANUFACTURING

### Email 1 - The Problem
**Subject:** Production downtime question

Hi [First Name],

Quick question: What does an hour of downtime cost [Company Name]?

Most manufacturers I work with in Gauteng lose:
• R5,000-R20,000 per hour when systems are down
• Days waiting for parts or technicians
• Sales when inventory systems fail

We monitor your critical systems 24/7 and fix issues before they stop production.

Interested in details?

Lutendo Kekana
LK Digital Solutions

---

### Email 2 - ROI Focus
**Subject:** Re: Production downtime

Hi [First Name],

Following up on my email about downtime costs.

Here's what we did for a manufacturing client in Kempton Park:

**Before:**
• 8 hours downtime per month
• Random IT bills averaging R12,000/month
• No monitoring (found problems after they happened)

**After (6 months with us):**
• 45 minutes total downtime
• Fixed R9,500/month
• Problems caught before production stops

ROI: They saved R180,000 in the first year.

Worth a 15-minute call to see if we can do similar for [Company Name]?

Lutendo

---

### Email 3 - Last Contact
**Subject:** Closing [Company Name]'s file

Hi [First Name],

I'll stop reaching out after this.

If downtime becomes a problem or IT costs get unpredictable, we're here.

Best,
Lutendo

---

## TEMPLATE SET 4: MEDICAL PRACTICES

### Email 1 - Compliance Focus
**Subject:** Patient data security at [Practice Name]

Hi Dr. [Last Name],

I specialize in IT for medical practices in Gauteng.

Most doctors I talk to are concerned about:
• Patient data security (POPIA compliance)
• Appointment systems going down
• Old computers slowing down consultations

Is [Practice Name] confident your patient data is properly protected?

We handle IT for several practices and make sure everything meets legal requirements.

Quick call this week?

Lutendo Kekana
LK Digital Solutions

---

### Email 2 - Risk Angle
**Subject:** Following up - [Practice Name]

Hi Dr. [Last Name],

Not sure if you saw my earlier message about patient data security.

A practice in Centurion recently had a laptop stolen with 200+ patient records on it. No encryption, no backup.

The POPIA fine alone was R500,000. Plus reputation damage.

We help practices like yours:
• Encrypt all patient data
• Automatic cloud backup
• Secure access from any device

It's easier (and cheaper) to prevent than to fix after a breach.

Interested in an audit?

Lutendo

---

### Email 3 - Final
**Subject:** Last message

Hi Dr. [Last Name],

This is my final follow-up.

If IT security is already handled, excellent. If not, and you ever need help with POPIA compliance or system reliability, we're here.

Best regards,
Lutendo

---

## TEMPLATE SET 5: GENERAL BUSINESSES (Catch-All)

### Email 1 - Universal Problem
**Subject:** IT costs at [Company Name]

Hi [First Name],

Simple question: Are your IT costs predictable month-to-month?

Most Gauteng businesses we work with had:
• R8,000 one month, R25,000 the next (no pattern)
• Long wait times when something broke
• No idea what they were actually paying for

We changed that with fixed monthly plans and same-day support.

10 minutes to explain how?

Lutendo Kekana
LK Digital Solutions

---

### Email 2 - Clarity
**Subject:** Re: IT costs

Hi [First Name],

Following up from my email about unpredictable IT costs.

Here's how we work:

**Fixed monthly fee** - No surprises, covers everything
**30-minute response time** - We pick up when you call
**Real person answers** - No offshore call centers

Current clients pay between R6,500-R15,000/month depending on team size.

They know exactly what they're spending and get faster support than before.

Worth a conversation?

Lutendo

---

### Email 3 - Breakup
**Subject:** Closing your file

Hi [First Name],

I'll assume IT isn't a focus area right now and close your file.

If costs spike or systems fail down the line, you know where to find me.

Cheers,
Lutendo

---

## SPECIAL TEMPLATES

### Reply to "Send me info"
**Subject:** Re: Info about LK Digital

Hi [First Name],

Thanks for getting back to me.

Rather than send a generic PDF, can I ask:
1. What's your biggest IT headache right now?
2. How many staff do you have?
3. What's your current IT setup (in-house, outsourced, nothing)?

That way I can send you something actually relevant to [Company Name].

10-minute call would be faster though. Are you free [Day] at [Time]?

Lutendo

---

### Reply to "Not interested"
**Subject:** Re: Not interested

Hi [First Name],

No problem at all. Can I ask what made you say not interested?

Is it:
A) Already have IT support you're happy with
B) Not the right time
C) Something else

Just helps me improve my outreach.

Either way, best of luck with [Company Name].

Lutendo

(Note: 20% of "not interested" replies turn into conversations with this follow-up)

---

### Reply to "What's your pricing?"
**Subject:** Re: Pricing

Hi [First Name],

Our pricing depends on:
• Number of staff/devices
• Current systems (cloud vs on-premise)
• Response time needs (same-day vs next-day)

Most Gauteng businesses with 5-20 staff pay between R6,500-R12,000/month.

That covers:
• Unlimited support calls
• System monitoring
• Security updates
• Monthly check-ins

Can I ask a few quick questions to give you an exact quote?

Or if you prefer, here's my calendar: [link]

Lutendo

---

### Reply to "Send me a proposal"
**Subject:** Re: Proposal for [Company Name]

Hi [First Name],

Happy to put something together.

Before I do, quick questions so it's actually useful:
1. What prompted you to look for IT support now?
2. What does good IT support look like for [Company Name]?
3. What's your decision timeline?

I can have a proposal over by [Day].

If you'd rather just talk it through, I'm free [Day] at [Time] or [Time].

Lutendo

---

## EMAIL BEST PRACTICES

### Subject Lines That Work
✓ "Quick question about [Company]"
✓ "IT costs at [Company]"
✓ "[Industry] firms in Gauteng"
✓ "Following up - [Company]"

### Subject Lines to Avoid
✗ "You need to read this"
✗ "Special offer inside"
✗ "URGENT: [anything]"
✗ Emojis or ALL CAPS

### Opening Lines
✓ Start with their problem
✓ Reference their industry
✓ Ask a specific question

✗ "I hope this email finds you well"
✗ "We are a leading provider of..."
✗ Long company introductions

### Call to Action
✓ "10 minutes to discuss?"
✓ "Worth a quick chat?"
✓ "Can I send details?"

✗ "Let me know if you're interested"
✗ "Feel free to reach out"
✗ "Looking forward to hearing from you"

### Signature
Always include:
• Your full name
• Company name
• Direct email
• Phone number (clickable on mobile)
• Unsubscribe link (legal requirement)

---

## PERSONALIZATION VARIABLES

Use these in Mautic:
• {contactfield=firstname} - First name
• {contactfield=lastname} - Last name
• {contactfield=company} - Company name
• {contactfield=industry} - Industry
• {contactfield=city} - City
• {unsubscribe_url} - Unsubscribe link

Example:
```
Hi {contactfield=firstname},

I work with {contactfield=industry} businesses in {contactfield=city}...
```

---

## A/B TESTING IDEAS

### Test These Variables:
1. **Subject Lines**
   - Question vs Statement
   - Company name vs Industry
   - Short (3 words) vs Longer (6-8 words)

2. **Email Length**
   - Short (100 words) vs Medium (200 words)

3. **Call to Action**
   - "Quick chat?" vs "10 minutes to discuss?"
   - Phone number vs Calendar link

4. **Social Proof**
   - With case study vs Without
   - Specific numbers vs General results

### How to Test in Mautic:
1. Create 2 versions of same email
2. Send Version A to 50% of segment
3. Send Version B to other 50%
4. After 3 days, check which performed better
5. Use winner for next campaign

---

## RESPONSE RATE BENCHMARKS

**Industry Averages (B2B Cold Email):**
• Open Rate: 20-30%
• Reply Rate: 1-5%
• Positive Reply: 0.5-2%
• Meeting Booked: 0.3-1%

**Translation per 1,000 emails:**
• 250 opens
• 20 replies
• 5 positive conversations
• 3 meetings
• 1 new client

**Red Flags:**
• Open rate <15% → Fix subject lines
• Reply rate <1% → Improve targeting/copy
• Bounce rate >5% → Clean email list
• Unsubscribe >2% → Wrong audience

---

## WHEN TO STOP EMAILING

Stop immediately if:
• Contact replies asking to stop
• Email bounces (hard bounce)
• They unsubscribe
• 3 emails sent with no opens (dead email)

Keep going if:
• They opened but didn't reply (try different angle)
• Soft bounce (temporary issue, retry later)
• Out of office reply (follow up after return date)

---

*Save these templates in Mautic and customize per industry.*
*Test, measure, improve.*
