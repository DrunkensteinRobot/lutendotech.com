#!/usr/bin/env python3
"""
Lead Collection Automation Script
For: LK Digital Solutions
Purpose: Collect business contacts from public sources in Gauteng, SA
"""

import csv
import re
import time
import requests
from bs4 import BeautifulSoup
from datetime import datetime

class LeadCollector:
    def __init__(self):
        self.leads = []
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def extract_emails_from_text(self, text):
        """Extract email addresses from text using regex"""
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        emails = re.findall(email_pattern, text)
        
        # Filter out common false positives
        filtered_emails = [
            email for email in emails 
            if not any(x in email.lower() for x in [
                'example', 'test', 'spam', 'noreply', 'mailer-daemon',
                'postmaster', 'abuse', 'privacy', 'yourcompany',
                '.png', '.jpg', '@sentry', 'wixpress'
            ])
        ]
        
        return list(set(filtered_emails))
    
    def extract_phone_numbers(self, text):
        """Extract South African phone numbers"""
        # SA phone patterns
        patterns = [
            r'\+27\s?\d{2}\s?\d{3}\s?\d{4}',  # +27 11 123 4567
            r'0\d{2}\s?\d{3}\s?\d{4}',         # 011 123 4567
            r'\(\d{3}\)\s?\d{3}\s?\d{4}',     # (011) 123 4567
        ]
        
        phones = []
        for pattern in patterns:
            phones.extend(re.findall(pattern, text))
        
        return list(set(phones))
    
    def scrape_website_contact_page(self, url, company_name, industry):
        """
        Scrape contact information from a website's contact page
        """
        print(f"Scraping: {url}")
        
        try:
            # Common contact page URLs
            contact_urls = [
                url + '/contact',
                url + '/contact-us',
                url + '/about',
                url + '/about-us',
                url
            ]
            
            emails = []
            phones = []
            
            for contact_url in contact_urls:
                try:
                    response = self.session.get(contact_url, timeout=10)
                    
                    if response.status_code == 200:
                        soup = BeautifulSoup(response.text, 'html.parser')
                        
                        # Extract text content
                        text = soup.get_text()
                        
                        # Find emails and phones
                        page_emails = self.extract_emails_from_text(text)
                        page_phones = self.extract_phone_numbers(text)
                        
                        emails.extend(page_emails)
                        phones.extend(page_phones)
                        
                        if emails:
                            break  # Found contact info, no need to check other pages
                    
                    time.sleep(1)  # Be polite, don't hammer servers
                    
                except Exception as e:
                    continue
            
            if emails:
                # Try to extract first name from email
                email = emails[0]
                name_part = email.split('@')[0]
                
                # Common patterns: john.smith, jsmith, john_smith
                if '.' in name_part:
                    first_name = name_part.split('.')[0].capitalize()
                elif '_' in name_part:
                    first_name = name_part.split('_')[0].capitalize()
                else:
                    first_name = name_part.capitalize()
                
                lead = {
                    'first_name': first_name,
                    'last_name': '',
                    'email': email,
                    'company': company_name,
                    'industry': industry,
                    'website': url,
                    'phone': phones[0] if phones else '',
                    'source': 'website_scrape',
                    'date_collected': datetime.now().strftime('%Y-%m-%d')
                }
                
                self.leads.append(lead)
                print(f"✓ Found: {email} at {company_name}")
                return True
            else:
                print(f"✗ No contact info found for {company_name}")
                return False
                
        except Exception as e:
            print(f"✗ Error scraping {url}: {str(e)}")
            return False
    
    def search_google_my_business(self, search_query, location="Gauteng"):
        """
        Note: This is a placeholder. Google doesn't allow automated GMB scraping.
        You should manually collect this data or use Google Maps Platform API (paid).
        
        Alternative: Manually search and copy results to CSV, then import.
        """
        print(f"\nTo collect from Google My Business:")
        print(f"1. Search: '{search_query} {location}' on Google Maps")
        print(f"2. Manually copy business names and websites")
        print(f"3. Add to gauteng_businesses.csv")
        print(f"4. Run this script to scrape their websites\n")
    
    def import_from_csv(self, filepath):
        """Import businesses from CSV to scrape"""
        businesses = []
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    businesses.append(row)
            
            print(f"Loaded {len(businesses)} businesses from {filepath}")
            return businesses
            
        except FileNotFoundError:
            print(f"File not found: {filepath}")
            return []
    
    def scrape_from_csv_list(self, csv_filepath):
        """
        Scrape websites from a CSV file containing business info
        Expected CSV columns: company_name, website, industry
        """
        businesses = self.import_from_csv(csv_filepath)
        
        successful = 0
        failed = 0
        
        for business in businesses:
            company = business.get('company_name', '')
            website = business.get('website', '')
            industry = business.get('industry', 'Unknown')
            
            if not website.startswith('http'):
                website = 'https://' + website
            
            success = self.scrape_website_contact_page(website, company, industry)
            
            if success:
                successful += 1
            else:
                failed += 1
            
            # Be polite - wait between requests
            time.sleep(2)
        
        print(f"\nResults: {successful} successful, {failed} failed")
        return self.leads
    
    def export_to_csv(self, filename='leads_export.csv'):
        """Export collected leads to CSV for Mautic import"""
        if not self.leads:
            print("No leads to export")
            return
        
        fieldnames = [
            'first_name', 'last_name', 'email', 'company', 
            'industry', 'website', 'phone', 'source', 'date_collected'
        ]
        
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(self.leads)
        
        print(f"\n✓ Exported {len(self.leads)} leads to {filename}")
        print(f"Import this file into Mautic under Contacts > Import")
    
    def validate_email(self, email):
        """Basic email validation"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def clean_leads(self):
        """Remove duplicates and invalid emails"""
        # Remove duplicates based on email
        seen_emails = set()
        cleaned_leads = []
        
        for lead in self.leads:
            email = lead['email'].lower()
            
            if email not in seen_emails and self.validate_email(email):
                seen_emails.add(email)
                cleaned_leads.append(lead)
        
        removed = len(self.leads) - len(cleaned_leads)
        self.leads = cleaned_leads
        
        print(f"Cleaned leads: Removed {removed} duplicates/invalid emails")


def create_sample_csv():
    """Create a sample CSV file with Gauteng businesses to scrape"""
    sample_data = [
        {'company_name': 'ABC Accounting', 'website': 'https://abcaccounting.co.za', 'industry': 'Accounting'},
        {'company_name': 'XYZ Legal', 'website': 'https://xyzlegal.co.za', 'industry': 'Legal'},
        {'company_name': 'Sample Manufacturing', 'website': 'https://samplemanufacturing.co.za', 'industry': 'Manufacturing'},
    ]
    
    with open('gauteng_businesses.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['company_name', 'website', 'industry'])
        writer.writeheader()
        writer.writerows(sample_data)
    
    print("Created gauteng_businesses.csv with sample data")
    print("Replace with real businesses before running scraper")


def main():
    """Main execution flow"""
    print("=" * 60)
    print("LK Digital Solutions - Lead Collection Tool")
    print("=" * 60)
    print()
    
    # Initialize collector
    collector = LeadCollector()
    
    # Check if input CSV exists
    import os
    if not os.path.exists('gauteng_businesses.csv'):
        print("gauteng_businesses.csv not found.")
        create_sample_csv()
        print("\nNext steps:")
        print("1. Edit gauteng_businesses.csv with real Gauteng businesses")
        print("2. Run this script again to scrape contact info")
        return
    
    print("Options:")
    print("1. Scrape websites from CSV list (gauteng_businesses.csv)")
    print("2. Create sample CSV template")
    print("3. Exit")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == '1':
        print("\nStarting scrape from gauteng_businesses.csv...")
        print("This may take several minutes depending on list size.\n")
        
        leads = collector.scrape_from_csv_list('gauteng_businesses.csv')
        
        if leads:
            collector.clean_leads()
            
            # Export results
            output_file = f"leads_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            collector.export_to_csv(output_file)
            
            print(f"\n{'=' * 60}")
            print(f"Success! Collected {len(leads)} leads")
            print(f"File: {output_file}")
            print(f"\nImport to Mautic:")
            print(f"1. Go to Contacts > Import")
            print(f"2. Upload {output_file}")
            print(f"3. Map columns (email → email, etc.)")
            print(f"4. Import to a segment")
            print(f"{'=' * 60}")
        else:
            print("\nNo leads collected. Check your input CSV.")
    
    elif choice == '2':
        create_sample_csv()
    
    else:
        print("Exiting...")


if __name__ == "__main__":
    main()
